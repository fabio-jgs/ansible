role vim: configurar syntax on
role bash: criar automaticamente o .bashrc
