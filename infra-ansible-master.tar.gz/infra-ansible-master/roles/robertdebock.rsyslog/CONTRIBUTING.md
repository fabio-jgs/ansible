# Please contribute

You can really make a difference by:

- [Making an issue](https://help.github.com/articles/creating-an-issue/). A well described issue helps a lot. (Have a look at the [known issues](https://github.com/search?q=user%3Arobertdebock+is%3Aissue+state%3Aopen).)
- [Making a pull request](https://services.github.com/on-demand/github-cli/open-pull-request-github) when you see the error in code.

I'll try to help and take every contribution seriously.

It's a great opportunity for me to learn how you use the role and also an opportunity to get into the habit of contributing to open source software.
